This directory includes precompiled static libraries for Win32/64 of OpenSSL Version 1.1.1e  from http://slproweb.com/products/Win32OpenSSL.html

The files are repacked from the following installers:

http://slproweb.com/download/Win32OpenSSL-1_1_1e.exe SHA1 d47c9d3dd908a17f7ca83014bf4cdc0f7c5431ba
http://slproweb.com/download/Win64OpenSSL-1_1_1e.exe SHA1 b0b2fa45fd4e4ab6b502495bd2d706b570196911

Original path and hashes of files:

(Win32InstallRoot)/lib/VC/static/

0bc40af9b8a5476fb2cb8847c3f51c543f892571d453c4018365f74a9de3d37e libcrypto32MD.lib
cbb33bcdfa060a479b11bb455c8bd636c0418e89759d5d37d712397dafce57ad libcrypto32MDd.lib
28429c0c06444c9be327f44c165de83aa04593006cd2abb4c943c4cc5041d076 libcrypto32MT.lib
17fef7b4dc1a8334af06411e1479cec940034eb8700e932d155b7aae4d2f86b4 libcrypto32MTd.lib

(Win64InstallRoot)/lib/VC/static/

9ca2cbea08f9464a37073d1b9a7bed90657ce69a6c9eb015954c308dfb30a653 libcrypto64MD.lib
099f98564e536fd07632dfd1f5efe98fc404aa1b6fd032e33681d18dcc613533 libcrypto64MDd.lib
eacc5e3864d50f872c8597c2d7e42c64c2c4d9414227a5afed5c85ebefab215c libcrypto64MT.lib
23123d2782170a506567c7f64d5b89d28e14fa67577b4685ecf10eb16e23b18c libcrypto64MTd.lib